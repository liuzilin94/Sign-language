"""
业务逻辑服务层 - 精简版
包含所有核心业务逻辑：认证、词汇、学习、复习等
"""
import os
import bcrypt
import json
from datetime import datetime, timedelta
from flask import current_app, request
from backend.models import db, User, Word, LearningRecord, ReviewSchedule, Post, Comment, DialectUpload, StudyStat

# ==================== 工具函数 ====================
def hash_password(password: str) -> str:
    """密码加密"""
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

def verify_password(password: str, password_hash: str) -> bool:
    """验证密码"""
    return bcrypt.checkpw(password.encode('utf-8'), password_hash.encode('utf-8'))

# ==================== 用户认证服务 ====================
class AuthService:
    """用户认证服务"""
    
    @staticmethod
    def register(username: str, phone: str, password: str):
        """
        用户注册
        Returns: (User, error_message)
        """
        # 参数验证
        if not username or len(username) < 2:
            return None, "用户名至少2个字符"
        if not phone or not phone.isdigit() or len(phone) != 11:
            return None, "手机号格式错误（11位数字）"
        if not password or len(password) < 6:
            return None, "密码至少6位"

        # 检查是否已存在
        if User.query.filter_by(phone=phone).first():
            return None, "手机号已注册"
        if User.query.filter_by(username=username).first():
            return None, "用户名已存在"

        # 创建用户
        user = User(
            username=username,
            phone=phone,
            password_hash=hash_password(password)
        )
        db.session.add(user)
        db.session.commit()

        return user, "注册成功"

    @staticmethod
    def login(phone: str, password: str):
        """
        用户登录
        Returns: (User, error_message)
        """
        if not phone or not password:
            return None, "参数不完整"

        user = User.query.filter_by(phone=phone).first()
        if not user:
            return None, "用户不存在"
        if not verify_password(password, user.password_hash):
            return None, "密码错误"

        # 更新最后活跃日期
        user.last_active_date = datetime.now().date()
        db.session.commit()

        return user, "登录成功"

# ==================== 词汇服务 ====================
class WordService:
    """词汇管理服务"""
    
    @staticmethod
    def get_words(page=1, page_size=20, category=None, difficulty=None, keyword=None):
        """
        获取词汇列表（支持分页和筛选）
        """
        query = Word.query

        if category:
            query = query.filter_by(category=category)
        if difficulty:
            query = query.filter_by(difficulty=difficulty)
        if keyword:
            query = query.filter(Word.word.like(f"%{keyword}%"))

        # 分页
        total = query.count()
        items = query.order_by(Word.id.asc()) \
                    .offset((page - 1) * page_size) \
                    .limit(page_size) \
                    .all()

        return {
            'items': [w.to_dict() for w in items],
            'total': total,
            'page': page,
            'page_size': page_size,
            'total_pages': (total + page_size - 1) // page_size
        }

    @staticmethod
    def get_word(word_id):
        """获取词汇详情"""
        word = Word.query.get(word_id)
        return word.to_dict() if word else None

    @staticmethod
    def get_word_by_backend_id(backend_id):
        """根据backend_id获取词汇"""
        word = Word.query.filter_by(backend_id=backend_id).first()
        return word.to_dict() if word else None

    @staticmethod
    def import_from_corpus(corpus_path):
        """从corpus.txt导入词汇（仅用于初始化）"""
        if not os.path.exists(corpus_path):
            print(f"⚠️  corpus.txt 不存在: {corpus_path}")
            return 0

        count = 0
        with open(corpus_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                parts = line.split('\t')
                if len(parts) >= 2:
                    backend_id = parts[0].strip()
                    word_text = parts[1].strip()

                    # 检查是否已存在
                    existing = Word.query.filter_by(backend_id=backend_id).first()
                    if existing:
                        continue

                    word = Word(
                        backend_id=backend_id,
                        word=word_text,
                        category='基础',
                        difficulty=1
                    )
                    db.session.add(word)
                    count += 1

        db.session.commit()
        return count

# ==================== 学习记录服务 ====================
class LearningService:
    """学习记录服务"""
    
    @staticmethod
    def create_record(user_id, word_id, is_correct=False, confidence=0.0):
        """
        创建练习记录
        学词标准：3次练习中至少2次成功，或连续2次成功 → 标记为已学会并创建复习计划
        Returns: dict (record)
        """
        record = LearningRecord.query.filter_by(user_id=user_id, word_id=word_id).first()
        if not record:
            record = LearningRecord(user_id=user_id, word_id=word_id)
            if record.practice_count is None:
                record.practice_count = 0
            if record.correct_count is None:
                record.correct_count = 0

        # 记录上一轮正确状态（用于判断连续正确）
        prev_correct = record.correct_count > 0 and record.avg_accuracy == 1.0

        record.practice_count += 1
        if is_correct:
            record.correct_count += 1
        record.avg_accuracy = record.correct_count / record.practice_count
        record.last_practice_at = datetime.now()

        # 判断是否满足"已学会"条件（且之前未标记为已学会）
        if not record.is_learned:
            total = record.practice_count
            correct = record.correct_count
            consecutive_ok = (prev_correct and is_correct)
            majority_ok = (total >= 3 and correct >= 2)
            # 满足任一条件：标记为已学会 + 创建复习计划
            if consecutive_ok or majority_ok:
                record.is_learned = True
                ReviewService._create_schedule(user_id, word_id)

        db.session.add(record)
        db.session.commit()

        return record.to_dict()

    @staticmethod
    def get_records(user_id):
        """获取用户所有学习记录"""
        records = LearningRecord.query.filter_by(user_id=user_id).all()
        return [r.to_dict() for r in records]

    @staticmethod
    def get_record(user_id, word_id):
        """获取单个学习记录"""
        record = LearningRecord.query.filter_by(user_id=user_id, word_id=word_id).first()
        return record.to_dict() if record else None

    @staticmethod
    def update_record(user_id, word_id, **kwargs):
        """更新学习记录（收藏、标记学会等）"""
        record = LearningRecord.query.filter_by(user_id=user_id, word_id=word_id).first()
        if not record:
            record = LearningRecord(user_id=user_id, word_id=word_id)
            # 确保字段有默认值
            if record.practice_count is None:
                record.practice_count = 0
            if record.correct_count is None:
                record.correct_count = 0

        # 更新字段
        for key, value in kwargs.items():
            if hasattr(record, key):
                setattr(record, key, value)

        db.session.add(record)
        db.session.commit()

        return record.to_dict()

    @staticmethod
    def get_learned_words(user_id):
        """获取已学会的词汇列表"""
        records = LearningRecord.query.filter_by(user_id=user_id, is_learned=True).all()
        return [r.word_id for r in records]

    @staticmethod
    def get_favorites(user_id):
        """获取收藏的词汇列表"""
        records = LearningRecord.query.filter_by(user_id=user_id, is_favorite=True).all()
        return [r.word_id for r in records]

# ==================== 复习服务（艾宾浩斯） ====================
class ReviewService:
    """复习计划服务 - 基于艾宾浩斯遗忘曲线"""
    
    # 复习间隔（天）
    REVIEW_INTERVALS = [1, 2, 4, 7, 15, 30]

    @staticmethod
    def get_today_reviews(user_id):
        """
        获取今日待复习词汇
        Returns: list of ReviewSchedule
        """
        today = datetime.now()
        schedules = ReviewSchedule.query.filter(
            ReviewSchedule.user_id == user_id,
            ReviewSchedule.next_review_at <= today
        ).all()

        return [s.to_dict() for s in schedules]

    @staticmethod
    def complete_review(user_id, word_id, is_correct=False):
        """
        完成一次复习（艾宾浩斯）
        复习成功 → 进入下一轮间隔；复习失败 → 间隔重置为1天
        同时同步更新 LearningRecord 的统计数据
        Returns: dict (schedule)
        """
        schedule = ReviewSchedule.query.filter_by(user_id=user_id, word_id=word_id).first()

        if not schedule:
            # 创建新的复习计划
            schedule = ReviewService._create_schedule(user_id, word_id)

        # 更新连续正确次数
        if is_correct:
            schedule.correct_count += 1
        else:
            schedule.correct_count = 0

        # 计算下次复习间隔
        idx = min(schedule.correct_count, len(ReviewService.REVIEW_INTERVALS) - 1)
        interval = ReviewService.REVIEW_INTERVALS[idx]
        schedule.interval = interval
        schedule.last_review_at = datetime.now()
        schedule.next_review_at = datetime.now() + timedelta(days=interval)

        db.session.add(schedule)

        # 同步更新 LearningRecord 的统计数据
        record = LearningRecord.query.filter_by(user_id=user_id, word_id=word_id).first()
        if record:
            record.practice_count += 1
            if is_correct:
                record.correct_count += 1
            record.avg_accuracy = record.correct_count / record.practice_count
            record.last_practice_at = datetime.now()
            db.session.add(record)

        db.session.commit()

        return schedule.to_dict()

    @staticmethod
    def _create_schedule(user_id, word_id):
        """创建初始复习计划"""
        schedule = ReviewSchedule(
            user_id=user_id,
            word_id=word_id,
            interval=1,
            next_review_at=datetime.now() + timedelta(days=1)
        )
        db.session.add(schedule)
        db.session.commit()
        return schedule

    @staticmethod
    def get_schedule(user_id, word_id):
        """获取单个复习计划"""
        schedule = ReviewSchedule.query.filter_by(user_id=user_id, word_id=word_id).first()
        return schedule.to_dict() if schedule else None

# ==================== 社区服务 ====================
class CommunityService:
    """社区动态服务"""
    
    @staticmethod
    def get_posts(page=1, page_size=20, sort_by='latest'):
        """获取动态列表（分页）"""
        query = Post.query.filter_by(status='published')

        if sort_by == 'hot':
            query = query.order_by(Post.likes_count.desc(), Post.created_at.desc())
        else:  # latest
            query = query.order_by(Post.created_at.desc())

        total = query.count()
        items = query.offset((page - 1) * page_size).limit(page_size).all()

        return {
            'items': [p.to_dict() for p in items],
            'total': total,
            'page': page,
            'page_size': page_size,
            'total_pages': (total + page_size - 1) // page_size
        }

    @staticmethod
    def create_post(user_id, content, images=None, video_url=None, word_tags=None):
        """发布动态"""
        post = Post(
            user_id=user_id,
            content=content,
            images=json.dumps(images) if images else None,
            video_url=video_url,
            word_tags=json.dumps(word_tags) if word_tags else None
        )
        db.session.add(post)
        db.session.commit()

        return post.to_dict()

    @staticmethod
    def delete_post(user_id, post_id):
        """删除动态（软删除）"""
        post = Post.query.get(post_id)
        if not post:
            return False, "动态不存在"
        if post.user_id != user_id:
            return False, "无权删除"

        post.status = 'deleted'
        db.session.commit()

        return True, "删除成功"

    @staticmethod
    def like_post(post_id):
        """点赞动态"""
        post = Post.query.get(post_id)
        if not post:
            return False, "动态不存在"

        post.likes_count += 1
        db.session.commit()

        return True, post.likes_count

    @staticmethod
    def unlike_post(post_id):
        """取消点赞"""
        post = Post.query.get(post_id)
        if not post:
            return False, "动态不存在"

        if post.likes_count > 0:
            post.likes_count -= 1
        db.session.commit()

        return True, post.likes_count

    @staticmethod
    def get_comments(post_id, page=1, page_size=20):
        """获取评论列表"""
        query = Comment.query.filter_by(post_id=post_id).order_by(Comment.created_at.asc())
        total = query.count()
        items = query.offset((page - 1) * page_size).limit(page_size).all()

        return {
            'items': [c.to_dict() for c in items],
            'total': total
        }

    @staticmethod
    def add_comment(post_id, user_id, content):
        """发表评论"""
        comment = Comment(post_id=post_id, user_id=user_id, content=content)
        db.session.add(comment)

        # 更新动态的评论数
        post = Post.query.get(post_id)
        if post:
            post.comments_count += 1

        db.session.commit()

        return comment.to_dict()

# ==================== 方言上传服务 ====================
class DialectService:
    """方言上传服务"""
    
    ALLOWED_EXTENSIONS = {'mp4', 'avi', 'mov', 'mkv', 'wmv'}

    @staticmethod
    def allowed_file(filename):
        """检查文件类型"""
        return '.' in filename and filename.rsplit('.', 1)[1].lower() in DialectService.ALLOWED_EXTENSIONS

    @staticmethod
    def upload_dialect(user_id, word_id, region, video_file, description=None):
        """
        上传方言视频
        Returns: (DialectUpload, error_message)
        """
        # 验证词汇是否存在
        word = Word.query.get(word_id)
        if not word:
            return None, "词汇不存在"

        # 保存文件
        upload_folder = current_app.config.get('UPLOAD_FOLDER', 'uploads')
        dialect_folder = os.path.join(upload_folder, 'dialects')
        os.makedirs(dialect_folder, exist_ok=True)

        # 生成唯一文件名
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{word_id}_{region.replace(' ', '_')}_{timestamp}.{video_file.filename.rsplit('.', 1)[1].lower()}"
        filepath = os.path.join(dialect_folder, filename)
        video_file.save(filepath)

        # 相对路径（用于URL）
        video_url = f"/uploads/dialects/{filename}"

        # 创建记录
        dialect = DialectUpload(
            user_id=user_id,
            word_id=word_id,
            region=region,
            video_url=video_url,
            description=description,
            status='pending'
        )
        db.session.add(dialect)
        db.session.commit()

        return dialect, "上传成功"

    @staticmethod
    def get_my_uploads(user_id):
        """获取我的上传记录"""
        dialects = DialectUpload.query.filter_by(user_id=user_id).order_by(DialectUpload.created_at.desc()).all()
        return [d.to_dict() for d in dialects]

    @staticmethod
    def get_word_dialects(word_id):
        """获取词汇的已审核方言"""
        dialects = DialectUpload.query.filter_by(
            word_id=word_id, 
            status='approved'
        ).all()
        return [d.to_dict() for d in dialects]

# ==================== 统计服务 ====================
class StatsService:
    """学习统计服务"""

    @staticmethod
    def get_overview(user_id):
        """获取学习概览"""
        from backend.models import Word
        user = User.query.get(user_id)
        records = LearningRecord.query.filter_by(user_id=user_id).all()

        total_practice = sum(r.practice_count for r in records)
        total_correct = sum(r.correct_count for r in records)
        avg_accuracy = total_correct / total_practice if total_practice > 0 else 0.0

        # 已学习的词汇数
        learned_words = LearningRecord.query.filter_by(user_id=user_id, is_learned=True).count()

        # 计算总学习时长（从练习记录估算）
        # 每次练习约3分钟
        total_minutes = total_practice * 3
        total_hours = round(total_minutes / 60, 1)

        # 掌握率：已掌握词汇数 / 已学习词汇数
        mastered_words = LearningRecord.query.filter_by(user_id=user_id, is_learned=True).count()
        mastery_rate = round(mastered_words / learned_words * 100, 1) if learned_words > 0 else 0

        # 成就数（暂时返回0，后续可扩展）
        achievements = 0

        return {
            'learned_words': learned_words,
            'total_words': Word.query.count(),
            'mastery_rate': mastery_rate,
            'total_hours': total_hours,
            'total_minutes': total_minutes,
            'level': user.level if user else 1,
            'exp': user.exp if user else 0,
            'points': user.points if user else 0,
            'streak_days': user.streak_days if user else 0,
            'achievements': achievements,
            'avg_accuracy': round(avg_accuracy * 100, 1),
            'total_practice': total_practice
        }

    @staticmethod
    def get_chart_data(user_id, period='week'):
        """
        获取图表数据
        period: 'week' | 'month' | 'year'
        返回数组格式: [{date, minutes, words_count}]
        """
        from datetime import date

        today = date.today()
        result = []

        if period == 'week':
            # 近7天
            for i in range(6, -1, -1):
                d = today - timedelta(days=i)
                stat = StudyStat.query.filter_by(user_id=user_id, date=d).first()
                # 每次练习约3分钟
                minutes = (stat.practice_count if stat else 0) * 3
                result.append({
                    'date': d.strftime('%Y-%m-%d'),
                    'minutes': minutes,
                    'words_count': stat.words_count if stat else 0,
                    'practice_count': stat.practice_count if stat else 0
                })

        elif period == 'month':
            # 近30天
            for i in range(29, -1, -1):
                d = today - timedelta(days=i)
                stat = StudyStat.query.filter_by(user_id=user_id, date=d).first()
                minutes = (stat.practice_count if stat else 0) * 3
                result.append({
                    'date': d.strftime('%Y-%m-%d'),
                    'minutes': minutes,
                    'words_count': stat.words_count if stat else 0,
                    'practice_count': stat.practice_count if stat else 0
                })

        elif period == 'year':
            # 整年，按月聚合
            year = int(request.args.get('year', today.year))
            for month in range(1, 13):
                stat = StudyStat.query.filter_by(user_id=user_id, date=date(year, month, 1)).first()
                month_minutes = 0
                month_words = 0
                month_practice = 0
                # 跨月汇总该月所有日
                from calendar import monthrange
                _, last_day = monthrange(year, month)
                for day in range(1, last_day + 1):
                    d = date(year, month, day)
                    s = StudyStat.query.filter_by(user_id=user_id, date=d).first()
                    if s:
                        month_minutes += (s.practice_count or 0) * 3
                        month_words += s.words_count or 0
                        month_practice += s.practice_count or 0
                result.append({
                    'date': f'{year}-{month:02d}',
                    'minutes': month_minutes,
                    'words_count': month_words,
                    'practice_count': month_practice
                })

        return result

    @staticmethod
    def get_radar_data(user_id):
        """
        获取雷达图数据：按词汇分类维度计算掌握度
        返回 {daily, social, emotion, life, tech} 各维度 0-100
        """
        category_map = {
            '日常': 'daily',
            '社会': 'social',
            '情感': 'emotion',
            '生活': 'life',
            '科技': 'tech',
        }
        result = {k: 0 for k in category_map.values()}

        records = (
            LearningRecord.query
            .join(Word)
            .filter(LearningRecord.user_id == user_id, LearningRecord.is_learned == True)
            .all()
        )
        if not records:
            return result

        cat_stats = {}
        for r in records:
            cat = r.word.category if r.word else '日常'
            key = category_map.get(cat, 'daily')
            if key not in cat_stats:
                cat_stats[key] = {'total': 0, 'correct': 0}
            cat_stats[key]['total'] += r.practice_count or 1
            cat_stats[key]['correct'] += r.correct_count or 0

        for key, stat in cat_stats.items():
            result[key] = round(
                (stat['correct'] / stat['total'] * 100) if stat['total'] > 0 else 0
            )

        return result

    @staticmethod
    def get_ranking(limit=10, user_id=None):
        """
        获取学习排行榜，按累计学习时长排序
        时长 = SUM(study_stats.minutes)
        user_id: 当前登录用户ID，用于标记 isMe
        """
        from sqlalchemy import func

        ranking = (
            db.session.query(
                User.id,
                User.username,
                User.avatar_url,
                User.level,
                func.coalesce(func.sum(StudyStat.minutes), 0).label('total_minutes')
            )
            .outerjoin(StudyStat, User.id == StudyStat.user_id)
            .group_by(User.id)
            .order_by(func.coalesce(func.sum(StudyStat.minutes), 0).desc())
            .limit(limit)
            .all()
        )

        return [
            {
                'id': row.id,
                'name': row.username,
                'avatar': row.avatar_url,
                'level': row.level,
                'hours': round(row.total_minutes / 60, 1),
                'minutes': row.total_minutes,
                'isMe': row.id == user_id
            }
            for row in ranking
        ]
