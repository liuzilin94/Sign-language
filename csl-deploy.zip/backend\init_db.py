"""
数据库初始化脚本
创建表、导入词汇、创建管理员账号
"""
import sys
import os

# 添加backend到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend'))

from app import app
from backend.models import db, User, Word
from backend.services import WordService
import bcrypt

def init_database():
    """初始化数据库"""
    with app.app_context():
        # 创建所有表
        db.create_all()
        print("[OK] 数据库表创建完成")

        # 导入词汇
        corpus_path = os.path.join('dataset', 'corpus.txt')
        if os.path.exists(corpus_path):
            count = WordService.import_from_corpus(corpus_path)
            print(f"[OK] 已导入 {count} 个词汇")
        else:
            print(f"⚠️  corpus.txt不存在，跳过词汇导入")

        # 创建默认管理员
        admin = User.query.filter_by(phone='13800000000').first()
        if not admin:
            admin = User(
                username='admin',
                phone='13800000000',
                password_hash=bcrypt.hashpw('admin123'.encode('utf-8'), bcrypt.gensalt()).decode('utf-8'),
                level=10,
                points=9999,
                role='admin'
            )
            db.session.add(admin)
            db.session.commit()
            print("[OK] 默认管理员已创建: admin / admin123 (角色: admin)")
        else:
            # 旧管理员账号补充 role 字段
            if not admin.role:
                admin.role = 'admin'
                db.session.commit()
                print("[OK] 管理员角色已更新")
            else:
                print("[OK] 管理员已存在")

        print("\n数据库初始化完成!")

if __name__ == '__main__':
    init_database()
